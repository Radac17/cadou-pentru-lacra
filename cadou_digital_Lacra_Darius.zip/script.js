// Schimbă codul aici dacă dorești alt PIN. Acesta este un cod de acces pentru surpriză,
 // nu o protecție puternică: codul poate fi găsit de cineva care inspectează fișierele site-ului.
const SECRET_PIN = "1811";

const lockScreen = document.getElementById("lockScreen");
const gift = document.getElementById("gift");
const pinForm = document.getElementById("pinForm");
const pinInput = document.getElementById("pin");
const pinError = document.getElementById("pinError");

pinForm.addEventListener("submit", (event) => {
  event.preventDefault();
  if (pinInput.value === SECRET_PIN) {
    lockScreen.classList.add("hidden");
    gift.classList.remove("hidden");
    window.scrollTo({ top: 0, behavior: "smooth" });
  } else {
    pinError.textContent = "Codul nu este corect. Mai încearcă, iubire. ♡";
    pinInput.value = "";
    pinInput.focus();
  }
});

const modal = document.getElementById("messageModal");
const modalText = document.getElementById("modalText");
function closeMessage() { modal.classList.add("hidden"); }
document.querySelectorAll(".surprise").forEach((button) => {
  button.addEventListener("click", () => {
    modalText.textContent = button.dataset.message;
    modal.classList.remove("hidden");
  });
});
document.getElementById("closeModal").addEventListener("click", closeMessage);
document.getElementById("modalOk").addEventListener("click", closeMessage);
modal.addEventListener("click", (event) => { if (event.target === modal) closeMessage(); });
document.addEventListener("keydown", (event) => { if (event.key === "Escape") closeMessage(); });
