CADOU DIGITAL PENTRU LACRA — DE LA DARIUS
==========================================

FIȘIERE
- index.html: conținutul site-ului
- style.css: designul roz romantic
- script.js: codul secret și surprizele interactive
- assets/: pune aici pozele voastre

PREVIZUALIZARE PE TELEFON / CALCULATOR
Deschide index.html în browser. Pentru a-l publica online, urmează pașii de mai jos.

1. PERSONALIZEAZĂ POZELE
Pune trei fotografii în folderul assets și numește-le exact:
  poza1.jpg
  poza2.jpg
  poza3.jpg
Dacă fotografiile sunt PNG, schimbă extensia în index.html sau convertește-le în JPG.
Nu există poze personale incluse în acest pachet.

2. PERSONALIZEAZĂ MESAJUL ȘI MUZICA
Deschide index.html într-un editor de text.
- Editează scrisoarea din secțiunea „O scrisoare pentru tine”.
- Înlocuiește linkurile demonstrative de la „Muzica noastră” cu linkuri către melodiile voastre.
- Editează mesajele din butoanele cu class="surprise" dacă dorești.

3. PUBLICĂ GRATUIT CU GITHUB PAGES
Ai nevoie de un cont GitHub.
- Intră pe https://github.com și creează un cont / autentifică-te.
- Creează un repository nou, de exemplu: cadou-pentru-lacra.
- Încarcă index.html, style.css, script.js și folderul assets cu pozele.
- În repository, intră la Settings → Pages.
- La Build and deployment, selectează Deploy from a branch.
- Alege branch-ul main și folderul /(root), apoi apasă Save.
- Așteaptă publicarea. GitHub îți va afișa un URL de forma:
  https://NUMEUTILIZATOR.github.io/cadou-pentru-lacra/
- Deschide linkul pe telefon ca să verifici și apoi trimite-l Lacrei.

IMPORTANT DESPRE CODUL SECRET
Codul 1811 oferă un moment drăguț de intrare, dar nu protejează cu adevărat conținutul:
cineva care inspectează fișierele poate găsi codul și mesajele. Nu pune informații private sau sensibile pe site.
Oricine are linkul poate încerca să acceseze pagina. Dacă vrei confidențialitate reală, ai nevoie de autentificare / protecție pe server.

COSTURI
GitHub Pages poate găzdui gratuit un site static public. Nu ai nevoie să cumperi domeniu personal; vei folosi URL-ul github.io.
